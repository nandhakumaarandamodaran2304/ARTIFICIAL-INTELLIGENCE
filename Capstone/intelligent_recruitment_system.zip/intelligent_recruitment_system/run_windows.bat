@echo off
title Intelligent Recruitment System
echo ============================================================
echo   Intelligent Recruitment System - Starting Application
echo ============================================================
if not exist venv (
    echo Creating Python virtual environment...
    python -m venv venv
)
call venv\Scripts\activate
echo Installing dependencies...
pip install -r requirements.txt --quiet
echo Launching server at http://127.0.0.1:5000 ...
python app.py
pause
