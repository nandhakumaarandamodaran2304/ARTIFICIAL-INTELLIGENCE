"""
Intelligent Recruitment System
Resume Analysis • Candidate Ranking • Job Recommendation
Authors: Nandhakumaaran D (192511312), Jaibalaji R (192526101)
SIMATS Engineering — Saveetha Institute of Medical and Technical Sciences
"""

import csv
import json
import math
import os
import re
import sqlite3
import sys
import threading
import webbrowser
from collections import Counter
from flask import Flask, jsonify, render_template, request

# Optional imports with graceful fallbacks so the app runs out-of-the-box
try:
    import fitz  # PyMuPDF
except ImportError:
    fitz = None

try:
    import docx  # python-docx
except ImportError:
    docx = None

try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False


def get_base_path():
    """Supports both direct Python execution and PyInstaller bundled .exe."""
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return sys._MEIPASS
    return os.path.dirname(os.path.abspath(__file__))


BASE_DIR = get_base_path()
DATA_DIR = os.path.join(BASE_DIR, "data")
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "recruitment.db")

app = Flask(
    __name__,
    template_folder=os.path.join(BASE_DIR, "templates"),
    static_folder=os.path.join(BASE_DIR, "static"),
)
app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024  # 10 MB upload limit

# Scoring Weights (Transparent by Design: 40% Skills + 25% Education + 20% Experience + 15% Similarity)
WEIGHTS = {
    "skills": 0.40,
    "education": 0.25,
    "experience": 0.20,
    "similarity": 0.15,
}

# Load Skill Normalization Taxonomy
with open(os.path.join(DATA_DIR, "skill_taxonomy.json"), "r", encoding="utf-8") as f:
    SKILL_TAXONOMY = json.load(f)


def normalize_skill(raw_skill: str) -> str:
    cleaned = raw_skill.strip().lower()
    for canonical, synonyms in SKILL_TAXONOMY.items():
        if cleaned == canonical or cleaned in synonyms:
            return canonical
    return cleaned


def extract_skills_from_text(text: str) -> list:
    lowered = text.lower()
    found = set()
    for canonical, synonyms in SKILL_TAXONOMY.items():
        for term in [canonical] + synonyms:
            pattern = r"(?<!\w)" + re.escape(term.lower()) + r"(?!\w)"
            if re.search(pattern, lowered):
                found.add(canonical)
                break
    return sorted(found)


def extract_text_from_upload(file_storage) -> str:
    filename = (file_storage.filename or "").lower()
    raw_bytes = file_storage.read()
    if filename.endswith(".pdf"):
        if fitz is not None:
            doc = fitz.open(stream=raw_bytes, filetype="pdf")
            text = "\n".join(page.get_text("text") for page in doc)
            doc.close()
            return text.strip()
        return raw_bytes.decode("utf-8", errors="ignore")
    elif filename.endswith(".docx"):
        if docx is not None:
            import io
            document = docx.Document(io.BytesIO(raw_bytes))
            return "\n".join(p.text for p in document.paragraphs).strip()
        return raw_bytes.decode("utf-8", errors="ignore")
    else:
        return raw_bytes.decode("utf-8", errors="ignore").strip()


def infer_education_from_text(text: str):
    lowered = text.lower()
    if any(k in lowered for k in ["ph.d", "phd", "doctorate"]):
        return "Ph.D.", 1.0
    if any(k in lowered for k in ["m.tech", "m.e.", "master", "m.sc", "mca"]):
        return "Postgraduate (M.Tech / M.Sc)", 0.95
    if any(k in lowered for k in ["b.tech", "b.e.", "bachelor", "b.sc", "bca", "computer science"]):
        return "Undergraduate (B.Tech / B.E.)", 0.88
    if any(k in lowered for k in ["diploma"]):
        return "Diploma", 0.72
    return "Unspecified Degree", 0.75


def infer_experience_years(text: str) -> float:
    matches = re.findall(r"(\d+(?:\.\d+)?)\s*\+?\s*(?:years?|yrs?)", text.lower())
    if matches:
        return min(max(float(m) for m in matches), 15.0)
    if "intern" in text.lower() or "fresher" in text.lower():
        return 0.5
    return 1.0


def compute_tfidf_cosine(doc_a: str, doc_b: str) -> float:
    if not doc_a.strip() or not doc_b.strip():
        return 0.0
    if SKLEARN_AVAILABLE:
        vectorizer = TfidfVectorizer(stop_words="english")
        try:
            matrix = vectorizer.fit_transform([doc_a, doc_b])
            sim = float(cosine_similarity(matrix[0:1], matrix[1:2])[0][0])
            return max(0.0, min(1.0, sim))
        except ValueError:
            return 0.0
    # Pure-Python TF-IDF Cosine fallback
    tokens_a = re.findall(r"[a-z0-9]+", doc_a.lower())
    tokens_b = re.findall(r"[a-z0-9]+", doc_b.lower())
    if not tokens_a or not tokens_b:
        return 0.0
    vocab = set(tokens_a) | set(tokens_b)
    ca, cb = Counter(tokens_a), Counter(tokens_b)
    dot = sum(ca[w] * cb[w] for w in vocab)
    norm_a = math.sqrt(sum(v * v for v in ca.values()))
    norm_b = math.sqrt(sum(v * v for v in cb.values()))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


def score_candidate_for_job(candidate: dict, job: dict) -> dict:
    """
    Transparent weighted matching engine:
    Total Score = 40% Skills + 25% Education + 20% Experience + 15% TF-IDF Text Similarity
    Excludes protected traits (name, gender, age, caste, religion, etc.) by design.
    """
    cand_skills = {normalize_skill(s) for s in candidate["skills"].split(",") if s.strip()}
    req_skills = [normalize_skill(s) for s in job["required_skills"].split(",") if s.strip()]
    pref_skills = [normalize_skill(s) for s in job["preferred_skills"].split(",") if s.strip()]

    matched_req = [s for s in req_skills if s in cand_skills]
    missing_req = [s for s in req_skills if s not in cand_skills]
    matched_pref = [s for s in pref_skills if s in cand_skills]
    missing_pref = [s for s in pref_skills if s not in cand_skills]

    req_ratio = len(matched_req) / len(req_skills) if req_skills else 1.0
    pref_ratio = len(matched_pref) / len(pref_skills) if pref_skills else 1.0
    skill_score = 0.80 * req_ratio + 0.20 * pref_ratio

    edu_score = max(0.0, min(1.0, float(candidate["education_score"])))

    exp_req = float(job["experience_required"])
    exp_cand = float(candidate["experience_years"])
    if exp_req <= 0:
        exp_score = 1.0
    else:
        exp_score = min(1.0, exp_cand / exp_req)

    cand_doc = f"{candidate['skills']} {candidate['summary']} {candidate['interests']}"
    job_doc = f"{job['title']} {job['required_skills']} {job['preferred_skills']} {job['description']}"
    sim_score = compute_tfidf_cosine(cand_doc, job_doc)

    skills_pts = round(WEIGHTS["skills"] * skill_score * 100, 1)
    edu_pts = round(WEIGHTS["education"] * edu_score * 100, 1)
    exp_pts = round(WEIGHTS["experience"] * exp_score * 100, 1)
    sim_pts = round(WEIGHTS["similarity"] * sim_score * 100, 1)
    total_pct = round(skills_pts + edu_pts + exp_pts + sim_pts, 1)

    if total_pct >= 80:
        fit_label = "High Match"
    elif total_pct >= 65:
        fit_label = "Good Match"
    else:
        fit_label = "Suggested Match"

    explanation = (
        f"Matched {len(matched_req)}/{len(req_skills)} required skills "
        f"({', '.join(s.upper() if len(s) <= 3 else s.title() for s in matched_req) or 'None'}) "
        f"with {int(round(sim_score * 100))}% resume-JD text similarity."
    )

    return {
        "candidate_id": candidate["candidate_id"],
        "label": candidate["label"],
        "education_level": candidate["education_level"],
        "experience_years": candidate["experience_years"],
        "experience_level": candidate["experience_level"],
        "job_id": job["job_id"],
        "job_title": job["title"],
        "department": job["department"],
        "total_score": total_pct,
        "fit_label": fit_label,
        "breakdown": {
            "skills": skills_pts,
            "education": edu_pts,
            "experience": exp_pts,
            "similarity": sim_pts,
        },
        "matched_skills": sorted(set(matched_req + matched_pref)),
        "missing_skills": sorted(set(missing_req + missing_pref)),
        "missing_required": missing_req,
        "explanation": explanation,
    }


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS candidates (
            candidate_id TEXT PRIMARY KEY,
            label TEXT NOT NULL,
            education_level TEXT NOT NULL,
            education_score REAL NOT NULL,
            experience_years REAL NOT NULL,
            experience_level TEXT NOT NULL,
            skills TEXT NOT NULL,
            interests TEXT NOT NULL,
            summary TEXT NOT NULL
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS jobs (
            job_id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            department TEXT NOT NULL,
            experience_required REAL NOT NULL,
            required_skills TEXT NOT NULL,
            preferred_skills TEXT NOT NULL,
            description TEXT NOT NULL
        )
    """)

    # Seed from CSV if empty
    if cur.execute("SELECT COUNT(*) FROM candidates").fetchone()[0] == 0:
        with open(os.path.join(DATA_DIR, "candidates.csv"), "r", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                cur.execute(
                    """INSERT INTO candidates
                       (candidate_id, label, education_level, education_score,
                        experience_years, experience_level, skills, interests, summary)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        row["candidate_id"], row["label"], row["education_level"],
                        float(row["education_score"]), float(row["experience_years"]),
                        row["experience_level"], row["skills"], row["interests"], row["summary"],
                    ),
                )

    if cur.execute("SELECT COUNT(*) FROM jobs").fetchone()[0] == 0:
        with open(os.path.join(DATA_DIR, "jobs.csv"), "r", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                cur.execute(
                    """INSERT INTO jobs
                       (job_id, title, department, experience_required,
                        required_skills, preferred_skills, description)
                       VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (
                        row["job_id"], row["title"], row["department"],
                        float(row["experience_required"]), row["required_skills"],
                        row["preferred_skills"], row["description"],
                    ),
                )

    conn.commit()
    conn.close()


def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/jobs", methods=["GET"])
def api_jobs():
    conn = get_db_connection()
    jobs = [dict(r) for r in conn.execute("SELECT * FROM jobs ORDER BY job_id").fetchall()]
    conn.close()
    return jsonify(jobs)


@app.route("/api/candidates", methods=["GET"])
def api_candidates():
    conn = get_db_connection()
    candidates = [dict(r) for r in conn.execute("SELECT * FROM candidates ORDER BY candidate_id").fetchall()]
    conn.close()
    return jsonify(candidates)


@app.route("/api/rank/<job_id>", methods=["GET"])
def api_rank_candidates(job_id):
    conn = get_db_connection()
    job_row = conn.execute("SELECT * FROM jobs WHERE job_id = ?", (job_id,)).fetchone()
    if not job_row:
        conn.close()
        return jsonify({"error": "Job not found"}), 404
    job = dict(job_row)
    candidates = [dict(r) for r in conn.execute("SELECT * FROM candidates").fetchall()]
    conn.close()

    ranked = [score_candidate_for_job(c, job) for c in candidates]
    ranked.sort(key=lambda x: x["total_score"], reverse=True)
    return jsonify({"job": job, "ranked_candidates": ranked})


@app.route("/api/recommend/<candidate_id>", methods=["GET"])
def api_recommend_jobs(candidate_id):
    conn = get_db_connection()
    cand_row = conn.execute("SELECT * FROM candidates WHERE candidate_id = ?", (candidate_id,)).fetchone()
    if not cand_row:
        conn.close()
        return jsonify({"error": "Candidate not found"}), 404
    candidate = dict(cand_row)
    jobs = [dict(r) for r in conn.execute("SELECT * FROM jobs").fetchall()]
    conn.close()

    recs = [score_candidate_for_job(candidate, j) for j in jobs]
    recs.sort(key=lambda x: x["total_score"], reverse=True)
    return jsonify({"candidate": candidate, "recommendations": recs})


@app.route("/api/upload_resume", methods=["POST"])
def api_upload_resume():
    text = ""
    if "resume" in request.files and request.files["resume"].filename:
        text = extract_text_from_upload(request.files["resume"])
    elif request.form.get("resume_text"):
        text = request.form.get("resume_text", "").strip()

    if not text:
        return jsonify({"error": "Please upload a PDF/DOCX/TXT file or paste resume text."}), 400

    label = request.form.get("label", "").strip() or "Uploaded Candidate"
    interests = request.form.get("interests", "").strip() or "AI products, software engineering"

    extracted_skills = extract_skills_from_text(text)
    if not extracted_skills:
        extracted_skills = ["python"]
    edu_level, edu_score = infer_education_from_text(text)
    exp_years = infer_experience_years(text)
    exp_level = "Fresher" if exp_years < 1.0 else ("Entry-level" if exp_years <= 2.0 else "Experienced")

    conn = get_db_connection()
    count = conn.execute("SELECT COUNT(*) FROM candidates").fetchone()[0]
    new_id = f"CAND_{count + 1:03d}"

    candidate = {
        "candidate_id": new_id,
        "label": label,
        "education_level": edu_level,
        "education_score": edu_score,
        "experience_years": exp_years,
        "experience_level": exp_level,
        "skills": ", ".join(extracted_skills),
        "interests": interests,
        "summary": text[:600],
    }

    conn.execute(
        """INSERT INTO candidates
           (candidate_id, label, education_level, education_score,
            experience_years, experience_level, skills, interests, summary)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            candidate["candidate_id"], candidate["label"], candidate["education_level"],
            candidate["education_score"], candidate["experience_years"],
            candidate["experience_level"], candidate["skills"],
            candidate["interests"], candidate["summary"],
        ),
    )
    conn.commit()
    jobs = [dict(r) for r in conn.execute("SELECT * FROM jobs").fetchall()]
    conn.close()

    recs = [score_candidate_for_job(candidate, j) for j in jobs]
    recs.sort(key=lambda x: x["total_score"], reverse=True)

    return jsonify({
        "candidate": candidate,
        "extracted_skills": extracted_skills,
        "recommendations": recs,
    })


def open_browser():
    webbrowser.open_new("http://127.0.0.1:5000")


if __name__ == "__main__":
    init_db()
    print("=" * 62)
    print("  Intelligent Recruitment System — SIMATS Engineering")
    print("  Running at: http://127.0.0.1:5000")
    print("  Press CTRL+C to stop the server.")
    print("=" * 62)
    if os.environ.get("NO_BROWSER") != "1":
        threading.Timer(1.2, open_browser).start()
    app.run(host="127.0.0.1", port=5000, debug=False)
