# Intelligent Recruitment System

**Resume Analysis • Candidate Ranking • Job Recommendation (AI + NLP + Human-in-the-Loop)**  
Developed by **Nandhakumaaran D (192511312)** & **Jaibalaji R (192526101)** — SIMATS Engineering.

## Quick Start (One-Click Run)
- **Windows:** Double-click `run_windows.bat` — it installs dependencies, starts the local Flask server, and opens `http://127.0.0.1:5000` in your browser.
- **macOS / Linux:** Run `./run_linux_mac.sh` in your terminal.

## Build a Standalone Windows `.exe`
Double-click `build_exe.bat` on Windows to compile the entire project into a single portable executable (`dist/IntelligentRecruitmentSystem.exe`) using PyInstaller.

## Architecture & Scoring Model
- **Parser:** PyMuPDF (`fitz`) + `python-docx` for PDF/DOCX extraction.
- **Skill Normalization:** Canonical skill taxonomy (`data/skill_taxonomy.json`) to eliminate keyword blind spots.
- **Matching Engine:** `40% Skills + 25% Education + 20% Experience + 15% TF-IDF Cosine Similarity`.
- **Database:** Auto-initialized SQLite (`recruitment.db`) seeded from `data/candidates.csv` and `data/jobs.csv`.
- **Responsible AI:** Excludes protected demographic traits and keeps all hiring decisions human-led.
