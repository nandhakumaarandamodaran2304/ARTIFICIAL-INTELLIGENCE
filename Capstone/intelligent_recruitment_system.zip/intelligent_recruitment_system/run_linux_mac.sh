#!/usr/bin/env bash
set -e
echo "============================================================"
echo "  Intelligent Recruitment System - Starting Application"
echo "============================================================"
if [ ! -d "venv" ]; then
  python3 -m venv venv
fi
source venv/bin/activate
pip install -r requirements.txt --quiet
python3 app.py
