@echo off
title Build Standalone Windows .EXE
echo Installing PyInstaller and dependencies...
pip install -r requirements.txt pyinstaller --quiet
echo Building IntelligentRecruitmentSystem.exe ...
pyinstaller --onefile --name IntelligentRecruitmentSystem ^
  --add-data "templates;templates" ^
  --add-data "static;static" ^
  --add-data "data;data" ^
  app.py
echo.
echo Done! Your standalone executable is in: dist\IntelligentRecruitmentSystem.exe
pause
